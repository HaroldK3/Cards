﻿/**
*--------------------------------------------------------------------
* File name: 1260-001-HaroldKaylee-Lab2
* Project name: Cards
*--------------------------------------------------------------------
* Author’s name and email: Kaylee Harold | haroldk@etsu.edu
* Course-Section: 001
* Creation Date: 2/6/2023
* -------------------------------------------------------------------
*/
using System;
namespace Cards
{
	public enum SuitofCard
	{
		Spades,
		Hearts,
		Diamonds,
		Clubs
	}

}
			

	


