﻿/**
*--------------------------------------------------------------------
* File name: 1260-001-HaroldKaylee-Lab2
* Project name: Cards
*--------------------------------------------------------------------
* Author’s name and email: Kaylee Harold | haroldk@etsu.edu
* Course-Section: 001
* Creation Date: 2/6/2023
* -------------------------------------------------------------------
*/
using System;
namespace Cards;
public class Program
{
    static void Main(string[] args)
    {

        Console.WriteLine("This is the original deck of cards.\n");
        Deck deck1 = new Deck();

        for (int i = 0; i < 52; i++)
        {
            Console.WriteLine(deck1.DealACard() );
        }
        Console.WriteLine("\n");


        deck1.Shuffle();

        Console.WriteLine("This is the original deck shuffled.\n");
        for (int i = 0; i < 52; i++)
        {
            Console.WriteLine(deck1.DealACard());
        }
        Console.WriteLine("\n");

        Console.WriteLine("This deal's player 1's hand of 7 cards.");
        Console.WriteLine("\n" + deck1.DealAHand(7) + "\n");

        Console.WriteLine("This deal's player 2's hand of 7 cards.");
        Console.WriteLine("\n" + deck1.DealAHand(7));

    }
}