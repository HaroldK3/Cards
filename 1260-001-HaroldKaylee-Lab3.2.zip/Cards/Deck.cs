﻿using System;
namespace Cards
{
	public class Deck
	{
        Card[] deckCards = new Card[52];

		int nextCard = 0;
		

        public Deck()
		{
			for (int i = 0; i < 52; i++)
			{
				Card card = new Card(i);
				deckCards[i] = card;
				
			}
			nextCard = 0;
        }
		
		public Deck(Deck existingDeck)
		{
			Card[] copyCard = new Card[deckCards.Length];

			for(int i = 0; i < deckCards.Length; i++)
			{
				copyCard[i] = deckCards[i];
			}
            nextCard = 0;
        }

		public void Shuffle()
		{
			Card[] temp = new Card[52];
            Random rand = new Random();
            
			for (int i = 0; i < 52; i++)
			{
                int rand2 = rand.Next(deckCards.Length);

				temp[i] = deckCards[rand2];
			}
			deckCards = temp;
            nextCard = 0;
        }

		public Card DealACard()
		{
				Card singleCard1 = deckCards[nextCard];
				nextCard++;
				return singleCard1;
			
		}

		
		public string DealAHand(int handSize)
		{
			if (nextCard > 51)
			{
				nextCard = 0;
			}
				string helper = "";
				Card hand = new Card();
				for (int i = 0; i < handSize; i++)
				{
					hand = deckCards[nextCard];
					nextCard++;
					helper += hand + "\n";
				}

			return helper;

        }
		
	}
}

